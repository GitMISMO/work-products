Below is a description of the files contained in this zip file:

CreditRequest_v2_1_1.dtd - Used to order ANY type of credit report. Includes the full Automated Underwriting System (AUS) 2.1 DTD structures within it, which allows the software vendor who already generates the AUS Loan Application to embed this structure "as is" within a credit request.
 
CreditRequest-MergeOnly_v2_1_1.dtd - Used to order only "Merge" reports. This DTD contains only minimal borrower information - enough to order a credit report.  XML files that validate against this DTD will also validate against the "CreditRequest_V2_1.dtd".

CreditResponse_v2_1_1.dtd - Used to generate ANY type of credit response - Merge Reports, RMCR, Score-Only Reports, Error Reports.

CreditReportingDictionaryt2_1_1.htm - This is the Logical Data Dictionary (LDD) that includes definitions for elements and attributes used in the three credit reporting DTDs.  This LDD definitions from the Credit Reporting, AUS and Service Ordering process areas.  

Brick(CreditResponse_v2_1_1).xml - Sample Credit Report file that validates against the "CreditResponse_V2_1_1.DTD" file.

Brick-IndividualMerge(CreditRequest-MergeOnly_v2_1_1).xml - Sample Credit Request showing how to order a "Merge" report for an individual. This file validates against the "CreditRequest-MergeOnly_v2_1_1.DTD" file OR the "CreditRequest_v2_1_1.DTD" file.

Brick-IndividualRMCR(CreditRequest_v2_1_1).xml - Sample Credit Request showing how to order an "RMCR" report for an individual. This file includes an AUS 2.1 Loan Application and validates against the "CreditRequest _v2_1_1.DTD" file.

Brick-JointMerge(CreditRequest-MergeOnly_v2_1_1).xml - Sample Credit Request showing how to order a "Merge" report for a married couple. This file validates against the "CreditRequest-MergeOnly_v2_1_1.DTD" file OR the "CreditRequest_v2_1_1.DTD" file.

Brick-JointRMCR(CreditRequest_v2_1_1).xml - Sample Credit Request showing how to order an "RMCR" report for a married couple. This file includes an AUS 2.1 Loan Application and validates against the "CreditRequest _v2_1_1.DTD" file.

Brick-MultipleMerge(CreditRequest-MergeOnly_v2_1_1).xml - Sample Credit Request showing how to order a "Merge" report for a married couple and another individual from the same loan. This file validates against the "CreditRequest-MergeOnly_v2_1_1.DTD" file OR the "CreditRequest_v2_1_1.DTD" file.

Brick-MultipleRMCR(CreditRequest_v2_1_1).xml - Sample Credit Request showing how to order an "RMCR" report for a married couple and another individual from the same loan. This file includes an AUS 2.1 Loan Application and validates against the "CreditRequest _v2_1_1.DTD" file.
