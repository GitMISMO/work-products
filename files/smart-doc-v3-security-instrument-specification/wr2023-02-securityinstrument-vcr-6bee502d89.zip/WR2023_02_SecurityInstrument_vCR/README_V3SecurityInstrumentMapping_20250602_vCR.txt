©2025 Mortgage Industry Standards Maintenance Organization, Inc. All Rights Reserved. 

NOTE:  The above copyright notice must be included in all copies of this MISMO Product and in any  derivative works based on this MISMO Product that are produced by End User.  

AUTHORIZED INTERNAL USE ONLY: This MISMO Product (as defined in MISMO’s 2018 Intellectual Property Rights Policy) is subject to a MISMO Product End-User License and grants the licensee the right to use this Product for Internal Use Only in accordance with the terms of that license.  Accordingly, this MISMO Product may be used for the development of material used for internal organizational purposes only and may not be shared, in whole or in part, outside of the licensee.  The applicable royalty fee for this MISMO Product is currently waived but when instituted will be as indicated on mismo.org. MISMO reserves the right to charge royalty fees upon expiration of any waiver.  Following such expiration, any further usage of the MISMO Product will be contingent on payment of such fees. 

REQUIRED LEGAL NOTICES: Per Section 7 of the End-User License, there are Legal Notices that must be included in all copies of this MISMO Product and in any derivative works based on this MISMO Product including any software applications developed by Distributor based upon this Product.  For details, see End-User License Required Legal Notices.  

In addition, per Section 2 of the End-User License, all copies of the Collateral (as defined by MISMO’s 2018 Intellectual Property Rights Policy) and any derivative works must attribute all content taken from the original item of Collateral to MISMO and carry the following legend: 

“This work is intended for internal use only within ____________ [Insert Name of End-User’s organization], a MISMO Collateral Licensee, and includes, in whole or in part, content from the [Insert Name of Collateral ____________________v. __, dated ____] published by the Mortgage Industry Standards Maintenance Organization, Inc. (“MISMO”). Your access through this work to the [name of Collateral], or parts thereof, does not convey to you any other rights to use, distribute, modify, reproduce, sell, sublicense, offer for sale, publish, or make derivative works of that MISMO product, or any portion of the product contained in this work. The right to make derivative works from any MISMO product is restricted by MISMO either to MISMO members and/or to those who pay the appropriate fee. Please contact MISMO for more information.” 

DISCLAIMERS. Attention is drawn to the possibility that some of the elements of this MISMO Product may be the subject of patent rights. MISMO will not be held responsible for identifying any or all such patent rights. This MISMO Product is subject to the MISMO Product End-User License Disclaimer and is provided “as is” with no warranties of any kind. 
______________________________________________________________________________________________________________________________________________________________________________

This zip file contains a Mapping Specification and SMART Doc V3 Verifiable Profile document samples created using the MISMO SMART Doc V3 Verifiable Profile specification. These documents are intended to be used as samples where the form fields can and should be modified to be dynamic to match the data setup for your organization. 

These SMART Doc V3 Verifiable Profile samples are for use with the MISMO Reference Model 3.6 or higher. 
