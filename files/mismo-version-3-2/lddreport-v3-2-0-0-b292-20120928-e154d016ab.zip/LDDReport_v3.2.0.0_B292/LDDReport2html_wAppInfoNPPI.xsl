<?xml version="1.0" encoding="UTF-8"?>
<!--
 $Id: LDDReport2html.xsl,v 1.11 2009/08/22 12:42:55 G. Greg Alvord Exp $

	 Render an MISMO LDD file to a simple HTML presentation.

     This provides the basic mechanics so that users can embellish on this
     presentation for their own purposes.

     To enable an MISMO LDD file to be rendered in a browser,
     add the following processing instruction to the start of the file:

     <?xml-stylesheet type="text/xsl" href="LDDReport2html.xsl"?>

     When in a Windows interface, drag the LDD Report file from the Windows
     Explorer to Mozilla Firefox or Internet Explorer to engage the stylesheet
     presentation.

	 The LDD_Report.xml file is created by reading the Liason Contivo .comp file and 
	 extracting the relavent information on Data point terms and Container terms.  
	 The is done by the LDDFULLReport.xsl documented seperately. 

     When creating standalone HTML from the XML, two examples of using nxslt2.exe 
	 available from http://www.xmllab.net/Downloads/tabid/61/Default.aspx
     are as follows, the first explicitly referencing the stylesheet and the
     second looking for the embedded stylesheet association:

       nxslt.exe LDD_Report.xml LDDReport2html.xsl -o LDDReport.html 


 Copyright (C) - MISMO
               - http://www.Mismo.org
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 
 - Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
 - Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
 - The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.
 
 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
 NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
 Note: for your reference, the above is the "Modified BSD license", this text
     was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5
-->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.w3.org/TR/REC-html40" xmlns:mismo="http://www.mismo.org/residential/2009/LDD" exclude-result-prefixes="mismo" version="1.0">
	<xsl:output indent="yes" method="html"/>
	<xsl:variable name="mismo:listTitle">LDD:</xsl:variable>
	<xsl:variable name="mismo:badDocElemTitle">Unexpected XML document for stylesheet</xsl:variable>
	<xsl:variable name="mismo:listHeading">LDD</xsl:variable>
	<xsl:template name="mismo:badDocElem">
		<xsl:param name="ns"/>
		<p>Unexpected XML document for <samp>LDDReport2html.xsl</samp> stylesheet.</p>
		<p>The document element is expected to be named
			<samp>LDD</samp>in the
			<samp>
				<xsl:value-of select="$ns"/>
			</samp>namespace, otherwise this message is displayed.</p>
		<p>What was found in this document is the document element named
			<samp>
				<xsl:value-of select="name(.)"/>
			</samp>in the
			<samp>
				<xsl:value-of select="namespace-uri(.)"/>
			</samp>namespace.</p>
	</xsl:template>

	<xsl:template match="/">
		<html>
			<head>
				<!--determine the text to put in the browser title bar-->
				<xsl:choose>
					<xsl:when test="mismo:LDD">
						<!--found what we are expecting-->
						<title>
							<xsl:copy-of select="$mismo:listTitle"/>
							<xsl:text>Version=</xsl:text>
							<xsl:value-of select="*/mismo:Identification/@version"/>
							<xsl:text>Build=</xsl:text>
							<xsl:value-of select="*/mismo:Identification/@build"/>
						</title>
					</xsl:when>
					<xsl:otherwise>
						<title>
							<xsl:copy-of select="$mismo:badDocElemTitle"/>
						</title>
					</xsl:otherwise>
				</xsl:choose>
			</head>
			<body>
				<xsl:apply-templates/>
				<p align="right">
					<small>
						<xsl:text/>Report created by <samp>LDDReport2html_wAppInfoNPPI.xsl</samp>
						<xsl:text> $Revision: 1.11 $ </xsl:text>
						<a href="http://www.mismo.org">
							<xsl:text>MISMO</xsl:text>
						</a>
					</small>
				</p>
			</body>
		</html>
	</xsl:template>

	<!--ooops ... the document element isn't what is expected-->
	<xsl:template match="/*">
		<xsl:call-template name="mismo:badDocElem">
			<xsl:with-param name="ns" select="string(document('')/*/namespace::mismo)"/>
		</xsl:call-template>
	</xsl:template>

	<!--========================================================================-->
	<!--the titling of the value list-->
	<xsl:template match="/mismo:LDD" priority="2">
		<h2>
			<a name="{generate-id(.)}">
				<xsl:copy-of select="$mismo:listHeading"/>
			</a>
		</h2>
		<!--show the meta data for the LDD-->
		<blockquote>
			<xsl:apply-templates select="mismo:Identification"/>
		</blockquote>
		<!--show the list content, including the meta data for the items-->
		<h2>Data Points</h2>
		<xsl:apply-templates select="mismo:DataPoints"/>
		<h2>Containers</h2>
		<xsl:apply-templates select="mismo:Containers"/>
		<h2>Attributes</h2>
		<xsl:apply-templates select="mismo:Attributes"/>
		<h2>Arc Roles</h2>
		<xsl:apply-templates select="mismo:ArcRoles"/>
	</xsl:template>
	<!--present the identification infromation in a table-->
	<xsl:template match="mismo:Identification">
		<table>
			<tr>
				<td valign="top">
					<samp>
						<xsl:value-of select="name(.)"/>
						<xsl:if test="@*">
							<xsl:text> (</xsl:text>
							<xsl:for-each select="@*">
								<xsl:if test="position()&gt;1">
									<xsl:text> </xsl:text>
								</xsl:if>
								<xsl:value-of select="concat(name(.),'=&quot;',.,'&quot;')"/>
							</xsl:for-each>
							<xsl:text>)</xsl:text>
						</xsl:if>
					</samp>
				</td>
				<td valign="top">
					<samp>=</samp>
				</td>
				<td valign="top">
					<samp>
						<xsl:value-of select="."/>
					</samp>
				</td>
			</tr>
			<tr>
				<td>Copyright 2011 Mortgage Industry Standards Maintenance Organization (MISMO) All rights reserved.</td>
			</tr>
			<tr>
				<td>THIS MISMO STANDARD INCLUDES THE END USER LICENSE AGREEMENT ATTACHED HERETO AT http://www.mismo.org/mismo/pdf/ipr_policy.pdf AND IS GOVERNED BY AND SUBJECT TO THE END USER LICENSE AGREEMENT. NO USER OF THIS STANDARD MAY REMOVE THIS REFERENCE TO AND STATEMENT REGARDING THE END USER LICENSE. ANY HARD COPY PUBLICATION OF THIS STANDARD MUST INCLUDE AND ATTACH A HARD COPY PRINT OUT OFTHE END USER LICENSE.  ANY FURTHER ELECTRONIC DISTRIBUTION OF THIS STANDARD MUST INCLUDE A SPECIFIC REFERENCED LINK TO THE END USER LICENSE AGREEMENT OR OTHER MEANS OF ATTACHMENT OF THE END USER LICENSE AGREEMENT.</td>
			</tr>
		</table>
	</xsl:template>
	<xsl:template match="mismo:DataPoints">
		<table border="1">
			<tr>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Data Point</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Definition</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Enumeration : Explantion </xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Enumeration : -- URN Suffix</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>App Info</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Type</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Personal Private Information</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>URN="urn:org:MISMO:residential:2009:LDD:" + suffix below</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Context</xsl:text>
					</sup>
				</th>
			</tr>
			<xsl:apply-templates select="mismo:Term">
				<xsl:sort select="@Name"/>
				<xsl:sort select="mismo:Type/mismo:Enum/@Value"/>
			</xsl:apply-templates>
		</table>
	</xsl:template>
	<xsl:template match="mismo:Term">
		<xsl:variable name="thisRow" select="."/>
		<tr>
			<td align="left" valign="top">
				<xsl:value-of select="@Name"/>
			</td>
			<td align="left" valign="top">
				<xsl:value-of select="@Definition"/>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="mismo:Type/mismo:Enum">
						<xsl:apply-templates select="mismo:Type/mismo:Enum" mode="noURN">
							<xsl:sort select="@Value"/>
						</xsl:apply-templates>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="mismo:Type/mismo:Enum">
						<xsl:apply-templates select="mismo:Type/mismo:Enum" mode="WithURN">
							<xsl:sort select="@Value"/>
						</xsl:apply-templates>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="@AppInfo">
						<xsl:value-of select="@AppInfo"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="mismo:Type[1]/@Name">
						<xsl:value-of select="substring(mismo:Type[1]/@Name,1,80)"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="@PPI and @PPIComment">
						<xsl:value-of select="concat(@PPI,' : ',@PPIComment)"/>
					</xsl:when>
					<xsl:when test="@PPI">
						<xsl:value-of select="@PPI"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="@URNSuffix">
						<xsl:value-of select="@URNSuffix"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<xsl:apply-templates select="mismo:Uses"/>
		</tr>
	</xsl:template>
	<xsl:template match="mismo:Enum" mode="noURN">
		<xsl:if test="not(preceding-sibling::mismo:Enum/@Value=./@Value)">
			<xsl:value-of select="concat(@Value,' : ',@Definition )"/>
		</xsl:if>
		<br/>
	</xsl:template>
	<xsl:template match="mismo:Enum" mode="WithURN">
		<xsl:if test="not(preceding-sibling::mismo:Enum/@Value=./@Value)">
			<xsl:value-of select="concat(@Value,'--',@URNSuffix )"/>
		</xsl:if>
		<br/>
	</xsl:template>
	<xsl:template match="mismo:Uses">
		<td align="left" valign="top">
			<xsl:text>Count=</xsl:text>
			<xsl:value-of select="@count"/>
			<br/>
			<xsl:apply-templates select="mismo:Used"/>
		</td>
	</xsl:template>
	<xsl:template match="mismo:Used">
		<xsl:text>Used in: </xsl:text>
		<xsl:value-of select="@in"/>
		<br></br>
		<xsl:text>     as: </xsl:text>
		<xsl:value-of select="@as"/>
		<br></br>
	</xsl:template>
	<xsl:template match="mismo:Containers">
		<table border="1">
			<tr>
				<th width="200">Container</th>
				<th width="500">Definition</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>URN="urn:org:MISMO:residential:2009:LDD:" + suffix below</xsl:text>
					</sup>
				</th>
				<th width="500">Context</th>
			</tr>
			<xsl:apply-templates select="mismo:Term" mode="Container">
				<xsl:sort select="@Name"/>
			</xsl:apply-templates>
		</table>
	</xsl:template>
	<xsl:template match="mismo:Term" mode="Container">
		<xsl:variable name="thisRow" select="."/>
		<tr>
			<td align="left" valign="top">
				<xsl:value-of select="@Name"/>
			</td>
			<td align="left" valign="top">
				<xsl:value-of select="@Definition"/>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="@URNSuffix">
						<xsl:value-of select="@URNSuffix"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<xsl:apply-templates select="mismo:Uses"/>
		</tr>
	</xsl:template>
	<xsl:template match="mismo:Attributes">
		<table border="1">
			<tr>
				<th width="200">Attribute</th>
				<th width="500">Definition</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>URN="urn:org:MISMO:residential:2009:LDD:" + suffix below</xsl:text>
					</sup>
				</th>
				<th width="500">Context</th>
			</tr>
			<xsl:apply-templates select="mismo:Term" mode="Attributes">
				<xsl:sort select="@Name"/>
			</xsl:apply-templates>
		</table>
	</xsl:template>
	<xsl:template match="mismo:Term" mode="Attributes">
		<xsl:variable name="thisRow" select="."/>
		<tr>
			<td align="left" valign="top">
				<xsl:value-of select="@Name"/>
			</td>
			<td align="left" valign="top">
				<xsl:value-of select="@Definition"/>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="@URNSuffix">
						<xsl:value-of select="@URNSuffix"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<xsl:apply-templates select="mismo:Uses"/>
		</tr>
	</xsl:template>
	<xsl:template match="mismo:ArcRoles">
		<table border="1">
			<tr>
				<th width="200">Attribute</th>
				<th width="500">Definition</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>Type</xsl:text>
					</sup>
				</th>
				<th align="center" valign="top">
					<sup>
						<xsl:text>URN="urn:org:MISMO:residential:2009:LDD:" + suffix below</xsl:text>
					</sup>
				</th>
				<th width="500">Context</th>
			</tr>
			<xsl:apply-templates select="mismo:Term" mode="ArcRoles">
				<xsl:sort select="@Name"/>
				<xsl:sort select="mismo:Type/mismo:Enum/@Value"/>
			</xsl:apply-templates>
		</table>
	</xsl:template>
	<xsl:template match="mismo:Term" mode="ArcRoles">
		<xsl:variable name="thisRow" select="."/>
		<tr>
			<td align="left" valign="top">
				<xsl:value-of select="@Name"/>
			</td>
			<td align="left" valign="top">
				<xsl:value-of select="@Definition"/>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="@URNSuffix">
						<xsl:value-of select="@URNSuffix"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
			<td align="left" valign="top">
				<xsl:choose>
					<xsl:when test="mismo:Type/mismo:Enum">
						<xsl:apply-templates select="mismo:Type/mismo:Enum">
							<xsl:sort select="@Value"/>
						</xsl:apply-templates>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
		</tr>
	</xsl:template>
</xsl:stylesheet><!-- Stylus Studio meta-information - (c) 2004-2009. Progress Software Corporation. All rights reserved.

<metaInformation>
	<scenarios>
		<scenario default="no" name="Presentationsmall" userelativepaths="yes" externalpreview="no" url="LDD_ReportFullV2.xml" htmlbaseurl="" outputurl="LDD_Report.htm" processortype="msxmldotnet" useresolver="no" profilemode="0" profiledepth=""
		          profilelength="" urlprofilexml="" commandline="" additionalpath="" additionalclasspath="" postprocessortype="none" postprocesscommandline="" postprocessadditionalpath="" postprocessgeneratedext="" validateoutput="no" validator="internal"
		          customvalidator="">
			<advancedProp name="sInitialMode" value=""/>
			<advancedProp name="bXsltOneIsOkay" value="true"/>
			<advancedProp name="bSchemaAware" value="true"/>
			<advancedProp name="bXml11" value="false"/>
			<advancedProp name="iValidation" value="0"/>
			<advancedProp name="bExtensions" value="true"/>
			<advancedProp name="iWhitespace" value="0"/>
			<advancedProp name="sInitialTemplate" value=""/>
			<advancedProp name="bTinyTree" value="true"/>
			<advancedProp name="bWarnings" value="true"/>
			<advancedProp name="bUseDTD" value="false"/>
			<advancedProp name="iErrorHandling" value="fatal"/>
		</scenario>
		<scenario default="yes" name="Scenario1" userelativepaths="yes" externalpreview="no" url="LDD_Report_Test.xml" htmlbaseurl="" outputurl="LDD_Report.htm" processortype="msxmldotnet" useresolver="no" profilemode="0" profiledepth="" profilelength=""
		          urlprofilexml="" commandline="" additionalpath="" additionalclasspath="" postprocessortype="none" postprocesscommandline="" postprocessadditionalpath="" postprocessgeneratedext="" validateoutput="no" validator="internal"
		          customvalidator="">
			<advancedProp name="sInitialMode" value=""/>
			<advancedProp name="bXsltOneIsOkay" value="true"/>
			<advancedProp name="bSchemaAware" value="true"/>
			<advancedProp name="bXml11" value="false"/>
			<advancedProp name="iValidation" value="0"/>
			<advancedProp name="bExtensions" value="true"/>
			<advancedProp name="iWhitespace" value="0"/>
			<advancedProp name="sInitialTemplate" value=""/>
			<advancedProp name="bTinyTree" value="true"/>
			<advancedProp name="bWarnings" value="true"/>
			<advancedProp name="bUseDTD" value="false"/>
			<advancedProp name="iErrorHandling" value="fatal"/>
		</scenario>
	</scenarios>
	<MapperMetaTag>
		<MapperInfo srcSchemaPathIsRelative="yes" srcSchemaInterpretAsXML="no" destSchemaPath="" destSchemaRoot="" destSchemaPathIsRelative="yes" destSchemaInterpretAsXML="no"/>
		<MapperBlockPosition></MapperBlockPosition>
		<TemplateContext></TemplateContext>
		<MapperFilter side="source"></MapperFilter>
	</MapperMetaTag>
</metaInformation>
-->